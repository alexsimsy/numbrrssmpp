import smpplib.gsm
import smpplib.client
import smpplib.consts
import threading
from loguru import logger
from .forwarder import forward_message
import asyncio

# SMPP Server configuration
LISTEN_PORT = 2875
SYSTEM_ID = 'simsy1'
SYSTEM_PASS = 'n9mb335m'

class SMPPServer:
    def __init__(self):
        self.server_socket = None
        self.running = False
        self.clients = []

    def handle_submit_sm(self, pdu):
        """Handle incoming SMS messages"""
        logger.info(f"Received message: source_addr={pdu.source_addr}, destination_addr={pdu.destination_addr}")
        
        # Create message object for forwarding
        message = type('SMPPMessage', (), {
            'destination': pdu.destination_addr.decode(),
            'source': pdu.source_addr.decode(),
            'short_message': pdu.short_message.decode(),
            'time': None,  # Could add current time if needed
            'log_id': None
        })

        # Run forward_message in the event loop
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(forward_message(message))
        finally:
            loop.close()

        return 0  # Success

    def handle_bind_transceiver(self, client, pdu):
        """Handle incoming bind requests"""
        if pdu.system_id.decode() == SYSTEM_ID and pdu.password.decode() == SYSTEM_PASS:
            logger.info(f"Client authenticated successfully: {pdu.system_id.decode()}")
            return 0  # Success
        else:
            logger.warning(f"Authentication failed for system_id: {pdu.system_id.decode()}")
            return smpplib.consts.SMPP_ESME_RINVPASWD

    def handle_client(self, client):
        """Handle individual client connection"""
        try:
            # Set up PDU handlers
            client.set_message_received_handler(lambda pdu: self.handle_submit_sm(pdu))
            client.set_message_sent_handler(lambda pdu: logger.debug(f"Message sent: {pdu.sequence}"))
            
            while self.running:
                client.read_once()
        except Exception as e:
            logger.error(f"Error handling client: {str(e)}")
        finally:
            if client in self.clients:
                self.clients.remove(client)

    def start(self):
        """Start the SMPP server"""
        import socket
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind(('0.0.0.0', LISTEN_PORT))
        self.server_socket.listen(5)
        self.running = True
        
        logger.info(f"SMPP Server listening on port {LISTEN_PORT}")
        
        while self.running:
            try:
                client_socket, addr = self.server_socket.accept()
                logger.info(f"New connection from {addr}")
                
                client = smpplib.client.Client(None, None)
                client.socket = client_socket
                client.bind_handler = lambda pdu: self.handle_bind_transceiver(client, pdu)
                
                self.clients.append(client)
                client_thread = threading.Thread(target=self.handle_client, args=(client,))
                client_thread.daemon = True
                client_thread.start()
                
            except Exception as e:
                logger.error(f"Error accepting connection: {str(e)}")
                if not self.running:
                    break

    def stop(self):
        """Stop the SMPP server"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        for client in self.clients:
            try:
                client.socket.close()
            except:
                pass
        self.clients = []

def run_server():
    """Run the SMPP server"""
    server = SMPPServer()
    try:
        server.start()
    except KeyboardInterrupt:
        logger.info("Shutting down SMPP server...")
    finally:
        server.stop()

if __name__ == "__main__":
    run_server() 